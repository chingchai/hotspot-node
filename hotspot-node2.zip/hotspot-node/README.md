# hotspot-node
Hotspot node API
## WMS CQL Filter 
- http://119.59.125.191/geoserver/omfs/wms?SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap&FORMAT=image/png&TRANSPARENT=true&STYLES&LAYERS=omfs:c40_landuse&CQL_FILTER=pv_tn='พะเยา'&SRS=EPSG:4326&bbox=99.2668228149414,17.7063083648682,101.367431640625,20.4783630371094&width=581&height=768&srs=EPSG:4326&format=application/openlayers

- http://119.59.125.191/geoserver/omfs/wms?SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap&FORMAT=image/png&TRANSPARENT=true&STYLES&LAYERS=omfs:c40_landuse&CQL_FILTER=pv_tn='เชียงราย'&SRS=EPSG:4326&bbox=99.2668228149414,17.7063083648682,101.367431640625,20.4783630371094&width=581&height=768&srs=EPSG:4326&format=application/openlayers
